import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface INewsdetailwpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    ID: number;
    Title: string;
    Likes: number;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    Published: Date;
    ImageUrl: string;
}
export default class NewsdetailwpWebPart extends BaseClientSideWebPart<INewsdetailwpWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListData();
    private CreateComment;
    private _SubmitButtonclick();
    private _getCommentsListData();
    private getCurrentUserWithAsyncAwait();
    private _renderListAsync();
    private _renderCommentsAsync();
    private _renderList(res);
    private _renderCommentsList(res);
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
