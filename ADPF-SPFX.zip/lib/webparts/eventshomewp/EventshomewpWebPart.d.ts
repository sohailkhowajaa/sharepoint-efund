import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IEventshomewpWebPartProps {
    description: string;
}
export interface EventsList {
    value: EventListItem[];
}
export interface EventListItem {
    Title: string;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    Start: Date;
    End: Date;
    IsActive: boolean;
    ImageUrl: string;
    Location: string;
    LocationAr: string;
}
export default class EventshomewpWebPart extends BaseClientSideWebPart<IEventshomewpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderList();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
