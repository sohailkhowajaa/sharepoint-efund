import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IEmiratenewswpWebPartProps {
    description: string;
}
export interface emiratenews {
    value: newsitem[];
}
export interface newsitem {
    Description: string;
    DescriptionAr: string;
}
export default class EmiratenewswpWebPart extends BaseClientSideWebPart<IEmiratenewswpWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListData();
    private _getdata();
    private _renderList();
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
