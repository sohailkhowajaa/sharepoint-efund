import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IEserviceswpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    ID: number;
    Title: string;
    TitleAr: string;
    link: string;
    parentid: number;
    icon: string;
    iconactive: string;
    target: string;
}
export default class EserviceswpWebPart extends BaseClientSideWebPart<IEserviceswpWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListData();
    private _renderListAsync();
    private _renderList();
    getphtml(id: any): string;
    submitevent(box: any): void;
    getshtml(id: any): string;
    backbuttonclick(pid: any): void;
    getparentid(id: any): number;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
