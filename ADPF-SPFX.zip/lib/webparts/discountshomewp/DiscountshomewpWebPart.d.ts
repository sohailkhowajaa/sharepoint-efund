import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IDiscountshomewpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    ID: number;
    Title: string;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    ProgramDescription: string;
    ProgramDescriptionAr: string;
    StartDate: string;
    EndDate: string;
    DiscountDuration: string;
}
export default class DiscountshomewpWebPart extends BaseClientSideWebPart<IDiscountshomewpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderList();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
