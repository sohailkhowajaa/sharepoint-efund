declare const styles: {
    newslistingwp: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    btnsearch: string;
};
export default styles;
