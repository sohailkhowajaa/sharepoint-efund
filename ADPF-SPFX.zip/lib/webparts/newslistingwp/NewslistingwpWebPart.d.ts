import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface INewslistingwpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    ID: number;
    Title: string;
    Likes: number;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    Published: Date;
    ImageUrl: string;
}
export default class NewslistingwpWebPart extends BaseClientSideWebPart<INewslistingwpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderListAsync();
    private _searchbuttonclick();
    private _searchtextboxenter();
    private _renderList(res);
    private _nextbuttonclick();
    private _previousbuttonclick();
    private SetupPagination(items, wrapper, rows_per_page);
    private PaginationButton(page, items);
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
