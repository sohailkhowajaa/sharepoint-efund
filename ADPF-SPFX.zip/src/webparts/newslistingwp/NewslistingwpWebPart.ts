import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './NewslistingwpWebPart.module.scss';
import * as strings from 'NewslistingwpWebPartStrings';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';


export interface INewslistingwpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}

export interface SPListItem {
  ID: number;
  Title: string;
  Likes: number;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  Published: Date;
  ImageUrl: string;
}
let currentpage = 0;
let itemsperpage = 10;
export default class NewslistingwpWebPart extends BaseClientSideWebPart<INewslistingwpWebPartProps> {

  public render(): void {
    var newslisting: string;
    if (this.context.pageContext.web.absoluteUrl.indexOf("en") > -1) {
      newslisting = "News Listing";
    } else {
      newslisting = 'قائمة الأخبار';
    }
    this.domElement.innerHTML = `
    <div class="${styles.newslistingwp}">
    <div class="col-xxl-12">
      <div class="row">
          <div class="col-sm-12 col-md-2 my-auto">
              <h3 class="fw-bold mb-0 text-center">${newslisting}</h3>
          </div>
          <div class="col-sm-12 col-md-10">
              <div class="news-search">
                  <div class="position-relative">
                      <input type="text" class="form-control" placeholder="Search..." autocomplete="off" id="newssearchtext" value="" style="padding:.5rem 0.9rem;">
                     <button id="searchbtn" class="${styles.btnsearch}"> <span class="mdi mdi-magnify search-widget-icon"></span></button>  
                      <span class="mdi mdi-close-circle search-widget-icon search-widget-icon-close d-none" id="search-close-options"></span>
                  </div>
              </div>
          </div>
      </div>
        <div id="spListContainer" >         
        </div>
    </div>`;
    this._renderListAsync();
    this._searchbuttonclick();
    this._searchtextboxenter();
  }

  private _getListData(): Promise<SPList> {
    var filterQuery;
    let searchboxVal: string = (this.domElement.querySelector('#newssearchtext') as HTMLInputElement).value;
    if (searchboxVal != "") {
      filterQuery = "?$filter=((IsActive  eq '1') and (substringof('" + searchboxVal + "',Title)))&&$orderby= Published desc";
    } else {
      filterQuery = "?$filter=IsActive  eq '1'&$orderby= Published desc";
    }
    var SiteURL =
      this.context.pageContext.site.absoluteUrl +
      `/_api/web/lists/GetByTitle('News and Announcements')/Items` +
      filterQuery;
    return this.context.spHttpClient
      .get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }

  private _renderListAsync(): void {
    this._getListData()
      .then((response) => {
        this._renderList(response);
      });
  }

  private _searchbuttonclick(): void {
    this.domElement.querySelector('#searchbtn').addEventListener('click', (event) => {
      event.preventDefault();
      console.log(currentpage);
      this._renderListAsync();
    });
  }

  private _searchtextboxenter(): void {
    var input = document.getElementById("newssearchtext");
    input.addEventListener("keypress", function (event) {
      if (event.key === "Enter") {
        event.preventDefault();
        document.getElementById("searchbtn").click();
      }
    });
  }

  private _renderList(res) {
    var SITEURL = this.context.pageContext.web.absoluteUrl;
    var flagEnglish = false;
    var noDataFound;
    var ListViewURL;
    var DetailViewUrl;
    var topic: string;
    var feature_a: string;
    var feature_b: string;

    if (SITEURL.indexOf("en") > -1) {
      flagEnglish = true;
      noDataFound = "No Data Found";
      topic = "News";
      feature_a = "View All";
      feature_b = "Read More";
    } else {
      noDataFound = "لاتوجد بيانات";
      topic = "أخبار";
      feature_a = "مشاهدة الكل";
      feature_b = "اقرأ أكثر";
    }
    let html: string = "";
    html = ``;
    var counter = 0;
    var totalcomments: Number = 0;
    var ItemURL;
    // this._getListData().then((response) => {    
    if (res != null) {
      if (res.value.length >= 1) {
        let start = itemsperpage * currentpage;
        let end = start + itemsperpage;
        let paginatedItems = res.value.slice(start, end);
        paginatedItems.forEach((item: SPListItem) => {
          let QLURL = item["Image"].Url;
          let Likes = item.Likes;
          let months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          let monthsAr = [
            "يناير",
            "فبراير",
            "مارس",
            "إبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
          ];
          let daysAr = ["الأحد", "الاثنين ", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
          var d = new Date(item.Published.toString());
          let date = d.getDate();
          let year = d.getFullYear();
          let day = days[d.getDay()];
          let month;

          var Title;
          var Description;
          if (flagEnglish) {
            Title = item.Title;
            Description = item.Description;
            month = months[d.getMonth()];
            day = days[d.getDay()];
            ItemURL = this.context.pageContext.site.absoluteUrl + "/en-us/Pages/newsdetail.aspx?newsid=" + item.ID;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/en-us/Pages/DetailsListPage.aspx?Parent=" +
              item.ID;
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/en-us/Pages/newsdetail.aspx?newsid=" +
              item.ID;
          } else {
            Title = item.TitleAr;
            Description = item.DescriptionAr;
            month = monthsAr[d.getMonth()];
            day = daysAr[d.getDay()];
            ItemURL = this.context.pageContext.site.absoluteUrl + "/ar-ae/Pages/newsdetail.aspx?newsid=" + item.ID;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/ar-ae/Pages/DetailsListPage.aspx?Parent=" +
              item.ID;
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/ar-ae/Pages/newsdetail.aspx?newsid=" +
              item.ID;
          }
          html += `<div class="card news-card2">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-12 col-md-1 text-center my-auto">
                        <div class="date">
                        <span>${date}</span>${month}<br>${year}
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-2 my-auto">
                        <img class="d-block img-fluid news-img2" src="${QLURL}" alt="First slide">
                    </div>
                    <div class="col-sm-12 col-md-9 news-details">
                        <h4 class="news-headlines"><a href="${ItemURL}">${Title}</a></h4>
                        <p class="news-text">${Description}</p>
                        <a class="news-read-more" href="${ItemURL}">Read More</a>
                    </div>
                </div>
            </div>
        </div>`;
        });
      } else {
        html += `<div class="card news-card2">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-1 text-center my-auto">
                
                </div>
                <div class="col-sm-12 col-md-9 news-details text-center">
                    <h4 class="news-headlines"><a href="#"></a></h4>
                    <p class="news-text">${noDataFound}</p>
                </div>
            </div>
        </div>
    </div>`;
      }
    } else {
      html += `<div class="card news-card2">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-1 text-center my-auto">
                    <div class="date">
                        <span></span><br>
                    </div>
                </div>
                <div class="col-sm-12 col-md-2 my-auto">
                    <img class="d-block img-fluid news-img2" src="#" alt="First slide">
                </div>
                <div class="col-sm-12 col-md-9 news-details">
                    <h4 class="news-headlines"><a href="#"></a></h4>
                    <p class="news-text">${noDataFound}</p>
                    <a class="news-read-more" href="#">Read More</a>
                </div>
            </div>
        </div>
    </div>`;
    }
    html += `<div class="row pt-3">
      <nav aria-label="Page navigation example">
          <ul class="pagination justify-content-center" >
          <li class="page-item" style="cursor: pointer;">
            <a class="page-link" href="#" aria-label="Previous" id="prebtn">
             <span aria-hidden="true">«</span>
            </a>
          </li>
          <div style="display:contents;" id="pagginationul"></div>
          <li class="page-item" style="cursor: pointer;">
           <a class="page-link" href="#" aria-label="Next" id="nextbtn">
               <span aria-hidden="true">»</span>
                 </a>
           </li>
           </ul>
      </nav>
  </div>
</div>`;

    const listContainer: Element =
      this.domElement.querySelector("#spListContainer");
    listContainer.innerHTML = html;
    const pagination_element = document.getElementById('pagginationul');
    this.SetupPagination(res.value, pagination_element, itemsperpage);
    this._nextbuttonclick();
    this._previousbuttonclick();
    // });
  }

  private _nextbuttonclick(): void {
    this.domElement.querySelector('#nextbtn').addEventListener('click', (event) => {
      event.preventDefault()
      currentpage=currentpage+1;
      this._renderListAsync();
    });
  }

  private _previousbuttonclick(): void {
    this.domElement.querySelector('#prebtn').addEventListener('click', (event) => {
      event.preventDefault();
      currentpage=currentpage-1;
      this._renderListAsync();
    });
  }

  private SetupPagination(items, wrapper, rows_per_page): void {
    let next=document.getElementById('nextbtn');
    let pre=document.getElementById('prebtn');  
    wrapper.innerHTML = "";
    if(currentpage==0)
    {pre.style.pointerEvents="none";
    pre.parentElement.style.cursor="not-allowed";
    }
    let page_count = Math.ceil(items.length / rows_per_page);
    if(currentpage==page_count-1)
    {
      next.style.pointerEvents="none";
      next.parentElement.style.cursor="not-allowed";
    }
    for (let i = 1; i < page_count+1; i++) {
      let btn = this.PaginationButton(i, items);
      wrapper.appendChild(btn);
    }
  }

  private PaginationButton(page, items) {
    let li = document.createElement('li');
    li.classList.add('page-item');
    li.style.cursor="pointer";
    let href = document.createElement('a');
    href.classList.add('page-link');
    li.appendChild(href);
    href.innerText = page;
    if (currentpage == page-1) li.classList.add('active');
    href.addEventListener('click', function () {
      currentpage =page-1;
      document.getElementById("searchbtn").click();
      let currentli = document.querySelector('.page-item.active');
      currentli.classList.remove('active');
      li.classList.add('active');
    });
    return li;
  }



  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
