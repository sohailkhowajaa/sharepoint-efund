/* tslint:disable */
require('./NewslistingwpWebPart.module.css');
const styles = {
  newslistingwp: 'newslistingwp_06d7360c',
  container: 'container_06d7360c',
  row: 'row_06d7360c',
  column: 'column_06d7360c',
  'ms-Grid': 'ms-Grid_06d7360c',
  title: 'title_06d7360c',
  subTitle: 'subTitle_06d7360c',
  description: 'description_06d7360c',
  button: 'button_06d7360c',
  label: 'label_06d7360c',
  btnsearch: 'btnsearch_06d7360c',
};

export default styles;
/* tslint:enable */