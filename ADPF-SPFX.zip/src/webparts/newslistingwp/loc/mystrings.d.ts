declare interface INewslistingwpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewslistingwpWebPartStrings' {
  const strings: INewslistingwpWebPartStrings;
  export = strings;
}
