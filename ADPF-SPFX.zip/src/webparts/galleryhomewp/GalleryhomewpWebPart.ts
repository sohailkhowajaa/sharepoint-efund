import { Version } from '@microsoft/sp-core-library';
import {
    BaseClientSideWebPart,
    IPropertyPaneConfiguration,
    PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './GalleryhomewpWebPart.module.scss';
import * as strings from 'GalleryhomewpWebPartStrings';

import { SPComponentLoader } from '@microsoft/sp-loader';

import {
    SPHttpClient,
    SPHttpClientResponse
} from '@microsoft/sp-http';

export interface IGalleryhomewpWebPartProps {
    description: string;
}

export default class GalleryhomewpWebPart extends BaseClientSideWebPart<IGalleryhomewpWebPartProps> {

    public render(): void {
        this.domElement.innerHTML = `
    <div class="${styles.galleryhomewp}">
        <div id="spListContainer" >          
        </div>
    </div>`;

    SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/jquery/jquery.min.js', { globalExportsName: 'jQuery' }).then(($: any): void => {
        SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/bootstrap/js/bootstrap.bundle.min.js', { globalExportsName: 'bootstrap' }).then((): void => {
          this._renderListData();
        });
      });
    //this._renderListData();
    }

    private _getListData(): Promise<any> {
         var filterQuery = "?$filter=IsActive  eq '1'&$select=FileRef/FileRef,Title";
        var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('Gallery')/Items`+filterQuery;
        return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                return response.json();
            });
    }

    private _renderListData(): void {
        this._getListData()
            .then((response) => {
                var SITEURL = this.context.pageContext.web.absoluteUrl;
                var flagEnglish = false;
                var noDataFound;
                if (SITEURL.indexOf('en') > -1) {
                    flagEnglish = true;
                    noDataFound = "No Data Found";
                } else {
                    noDataFound = "لاتوجد بيانات";
                }
                let html: string = `<div class="card gallery-card">
        <div class="card-header">
            <div class="row">
                <div class="col-sm-12 col-md-10">
                    <h3 class="gallery mb-0">Gallery</h3>
                </div>
                <div class="col-sm-12 col-md-2 gallery-nav">
                    <button class="carousel-control-prev" type="button" data-bs-target="#gallery" data-bs-slide="prev">
                        <i class="bx bx-chevron-left"></i>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#gallery" data-bs-slide="next">
                        <i class="bx bx-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div id="gallery" class="carousel slide" data-ride="carousel" data-bs-interval="false">
                    <div class="carousel-inner">`;
                var counter = 0;
                if (response != null) {
                    var chunksize = 12;
                    var data = response.value;
                    var count = data.length;
                    var pagenumbers = Math.ceil(count / chunksize);
                    var gallery = [];
                    var arr;
                    for (let index = 1; index <= pagenumbers; index++) {
                        arr = data.slice(chunksize * index - chunksize, chunksize * index);
                        gallery.push(arr);
                    }
                    gallery.forEach(element => {
                        let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                        let monthsAr = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
                        if (counter == 0) {
                            html += `<div class="carousel-item active">
                <div class="portfolio-item row">`;
                counter++;
                        }
                        else {
                            html += `<div class="carousel-item">
                <div class="portfolio-item row">`
                        }
                        element.forEach(element => {
                            html += `<div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                    <img class="img-fluid" src=${element.FileRef} alt="">
                </a>
            </div>`;
                        });
                        html += `</div>
            </div>`;
                    });
                }
                else {
                    html += `<div class="col-4 text-center">
         ${noDataFound}
      </div>`;
                }
                html += `</div>
        </div>
    </div>
</div>
</div>`;
                const listContainer: Element = this.domElement.querySelector('#spListContainer');
                listContainer.innerHTML = html;
            });
    }

    protected get dataVersion(): Version {
        return Version.parse('1.0');
    }

    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
        return {
            pages: [
                {
                    header: {
                        description: strings.PropertyPaneDescription
                    },
                    groups: [
                        {
                            groupName: strings.BasicGroupName,
                            groupFields: [
                                PropertyPaneTextField('description', {
                                    label: strings.DescriptionFieldLabel
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    }
}
