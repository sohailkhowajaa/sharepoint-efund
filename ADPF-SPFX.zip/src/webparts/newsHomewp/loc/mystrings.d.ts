declare interface INewsHomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewsHomewpWebPartStrings' {
  const strings: INewsHomewpWebPartStrings;
  export = strings;
}
