import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './EventshomewpWebPart.module.scss';
import * as strings from 'EventshomewpWebPartStrings';

import { SPComponentLoader } from '@microsoft/sp-loader';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface IEventshomewpWebPartProps {
  description: string;
}

export interface EventsList {
  value: EventListItem[];
}

export interface EventListItem {
  Title: string;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  Start: Date;
  End: Date;
  IsActive: boolean;
  ImageUrl: string;
  Location: string;
  LocationAr: string;
}

export default class EventshomewpWebPart extends BaseClientSideWebPart<IEventshomewpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.eventshomewp}">
      <div id="spListContainer" >          
      </div>
  </div>`;

  SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/jquery/jquery.min.js', { globalExportsName: 'jQuery' }).then(($: any): void => {
    SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/bootstrap/js/bootstrap.bundle.min.js', { globalExportsName: 'bootstrap' }).then((): void => {
      this._renderList();
    });
  });
//this._renderList();
  }

  private _getListData(): Promise<EventsList> {
    var filterQuery = "?$top=4&$filter=IsActive  eq '1'";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('Events')/Items` + filterQuery;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }
  private _renderList(): void {
    this._getListData().then((response) => {
      var SITEURL = this.context.pageContext.web.absoluteUrl;
      var noDataFound;
      var flagEnglish = false;

      if (SITEURL.indexOf('en') > -1) {
        flagEnglish = true;
        noDataFound = "No Data Found";
      } else {
        noDataFound = "لاتوجد بيانات";
      }

      let html: string = '<div class="card upcoming-events-card">';
      html += `<div class="card-header">
        <div class="row">
            <div class="col-sm-12 col-md-10">
                <h3 class="upcoming-events mb-0">Upcoming Events</h3>
            </div>
            <div class="col-sm-12 col-md-2 upcoming-events-nav">
                <button class="carousel-control-prev" type="button" data-bs-target="#events" data-bs-slide="prev">
                    <i class="bx bx-chevron-left"></i>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#events" data-bs-slide="next">
                    <i class="bx bx-chevron-right"></i>
                </button>
            </div>
        </div>
    </div>`;
      html += `
    <div class="card-body">
       <div class="row align-items-end">
        <div class="col-sm-12 px-2">
           <div id="events" class="carousel slide" data-ride="carousel" data-bs-interval="false">
             <div class="carousel-inner px-2">
    `;
      var counter = 0;
      if (response != null) {
        response.value.forEach((item: EventListItem) => {
          var Title;
          var Description;
          var Location;
          let QLURL = item["Image"].Url;
          let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
          let monthsAr = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
          var s = new Date(item.Start.toString());
          var e = new Date(item.End.toString());
          let startDate = s.getDate();
          let startYear = s.getFullYear();
          let endDate = e.getDate();
          let endYear = e.getFullYear();
          let startMonth;
          let endMonth;

          if (flagEnglish) {
            Title = item.Title;
            Description = item.Description;
            Location = item.Location;
            startMonth = months[s.getMonth()];
            endMonth = months[e.getMonth()];
          } else {
            Title = item.TitleAr;
            Description = item.DescriptionAr;
            Location = item.LocationAr;
            startMonth = monthsAr[s.getMonth()];
            endMonth = monthsAr[e.getMonth()];
          }

          if (counter == 0) {
            html += `<div class="carousel-item active">
            <div class="row events-detail">
                <div class="col-sm-12 col-md-12 col-lg-3">
                    <p class="event-date">${startDate}</p>
                    <div class="event-month">${startMonth}</div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-9 events-desc">
                    <p class="event-headlines">${Title}</p>
                    <p class="event-place">${Location}</p>
                </div>
            </div>
        </div>`;
            counter++;
          } else {
            html += `<div class="carousel-item">
            <div class="row pt-2">
                <div class="col-sm-12 col-md-12 col-lg-3">
                    <p class="event-date">${startDate}</p>
                    <div class="event-month">${startMonth}</div>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-9 events-desc">
                    <p class="event-headlines">${Title}</p>
                    <p class="event-place">${Location}</p>
                </div>
            </div>
        </div>`;
          }


        });
      }
      else {
        html += `<div class="carousel-item active">
        <div class="row events-detail">
            <div class="col-sm-12 col-md-12 col-lg-3">
                <p class="event-date"></p>
                <div class="event-month"></div>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-9 events-desc">
                <p class="event-headlines">${noDataFound}</p>
                <p class="event-place"></p>
            </div>
        </div>
    </div>`;
      }
      html += `</div>
      </div>
  </div>
</div>
</div> 
</div>`;
      const listContainer: Element = this.domElement.querySelector('#spListContainer');
      listContainer.innerHTML = html;
    });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
