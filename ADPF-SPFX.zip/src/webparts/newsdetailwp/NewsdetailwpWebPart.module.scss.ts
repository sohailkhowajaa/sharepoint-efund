/* tslint:disable */
require('./NewsdetailwpWebPart.module.css');
const styles = {
  newsdetailwp: 'newsdetailwp_86362d46',
  container: 'container_86362d46',
  row: 'row_86362d46',
  column: 'column_86362d46',
  'ms-Grid': 'ms-Grid_86362d46',
  title: 'title_86362d46',
  subTitle: 'subTitle_86362d46',
  description: 'description_86362d46',
  button: 'button_86362d46',
  label: 'label_86362d46',
};

export default styles;
/* tslint:enable */