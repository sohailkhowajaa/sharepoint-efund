declare interface INewsdetailwpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewsdetailwpWebPartStrings' {
  const strings: INewsdetailwpWebPartStrings;
  export = strings;
}
