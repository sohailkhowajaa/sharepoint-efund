import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';
import { UrlQueryParameterCollection } from '@microsoft/sp-core-library';

import styles from './NewsdetailwpWebPart.module.scss';
import * as strings from 'NewsdetailwpWebPartStrings';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface INewsdetailwpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}

export interface SPListItem {
  ID: number;
  Title: string;
  Likes: number;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  Published: Date;
  ImageUrl: string;
}
var userdetails=[];
var allcomments=[];
var NewsID;
export default class NewsdetailwpWebPart extends BaseClientSideWebPart<INewsdetailwpWebPartProps> {

  public render(): void {
    this.getCurrentUserWithAsyncAwait().then((res) => {
     userdetails.push(res);
    });
    var newslisting: string;
    if (this.context.pageContext.web.absoluteUrl.indexOf("en") > -1) {
      newslisting = "News Listing";
    } else {
      newslisting = 'قائمة الأخبار';
    }
    this.domElement.innerHTML = `<div class="${styles.newsdetailwp}">
        <div id="spListContainer" >         
        </div>
    </div>`;
    this._renderListAsync();

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListData(): Promise<SPList> {
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    NewsID = queryParms.getValue("newsid");
    var response = null;
    var list = null;
    var filterQuery = "?$filter=(IsActive eq '1') and (ID eq '" + NewsID + "')";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('News and Announcements')/Items` + filterQuery;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }

  private CreateComment = (): void => {
    let body: string="";
    if (this.context.pageContext.web.absoluteUrl.indexOf("en-us") > -1) {
      body= JSON.stringify({
        'Title': userdetails[0].DisplayName,
        'User_x0020_Name': userdetails[0].DisplayName,
        'User_x0020_Comments':document.getElementById("commentarea")['value'],
        'User_x0020_Email':userdetails[0].AccountName,
        'News_x0020_ID':NewsID,
      });
    }else{
      body= JSON.stringify({
        'Title': userdetails[0].DisplayName,
        'User_x0020_Name': userdetails[0].DisplayName,
        'User_x0020_Comments_x0020_Ar':document.getElementById("commentarea")['value'],
        'User_x0020_Email':userdetails[0].AccountName,
        'News_x0020_ID':NewsID,
      });
    } 
    this.context.spHttpClient.post(`${this.context.pageContext.site.absoluteUrl}/_api/web/lists/getbytitle('News Comments')/items`,
      SPHttpClient.configurations.v1, {
      headers: {
        'Accept': 'application/json;odata=nometadata',
        'Content-type': 'application/json;odata=nometadata',
        'odata-version': ''
      },
      body: body
    })
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            alert(`Yours Comments Added Successfully!`);
            this._renderCommentsAsync();
          });
        } else {
          response.json().then((responseJSON) => {
            //console.log(responseJSON);
            });
        }
      }).catch(error => {
        console.log(error);
      });
  }

  private _SubmitButtonclick(): void {
    document.getElementById('btnsubmit').addEventListener('click', (event) => {
      this.CreateComment();
      event.preventDefault(); 
    });
  }

  private _getCommentsListData(): Promise<SPList> {
    var queryParms = new UrlQueryParameterCollection(window.location.href);
    //var ID = queryParms.getValue("newsid");
    var response = null;
    var list = null;
    var filterQuery = "?$filter=(IsActive eq '1') and (News_x0020_ID eq '" + NewsID + "')";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('News Comments')/Items` + filterQuery;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }

  private async getCurrentUserWithAsyncAwait() {
    SPHttpClient
    let userlogin = "'ADPENTEST\\efunddb'";
    userlogin=this.context.pageContext.user.loginName;
    console.log(userlogin);
    var url_a=this.context.pageContext.site.absoluteUrl + `/_api/SP.UserProfiles.PeopleManager/GetMyProperties?$select=PictureUrl,AccountName,Title,DisplayName,PersonalUrl`;
    var url = this.context.pageContext.site.absoluteUrl + `/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v=`+userlogin;
    var response = await this.context.spHttpClient.get(url_a, SPHttpClient.configurations.v1);
    return await response.json();
  }

  private _renderListAsync(): void {
    this._getListData()
      .then((response) => {
        this._renderList(response);
      });
  }

  private _renderCommentsAsync(): void {
    this._getCommentsListData()
      .then((response) => {
        this._renderCommentsList(response);
      });
  }

  private _renderList(res) {
    var SITEURL = this.context.pageContext.web.absoluteUrl;
    var flagEnglish = false;
    var noDataFound;
    var ListViewURL;
    var DetailViewUrl;
    var topic: string;
    var feature_a: string;
    var feature_b: string;

    if (SITEURL.indexOf("en") > -1) {
      flagEnglish = true;
      noDataFound = "No Data Found";
      topic = "News";
      feature_a = "View All";
      feature_b = "Read More";
    } else {
      noDataFound = "لاتوجد بيانات";
      topic = "أخبار";
      feature_a = "مشاهدة الكل";
      feature_b = "اقرأ أكثر";
    }
    let html: string = "";
    html = ``;
    var counter = 0;
    var totalcomments: Number = 0;
    var ItemURL;
    if (res != null) {
      if (res.value.length >= 1) {
        res.value.forEach((item: SPListItem) => {
          let QLURL = item["Image"].Url;
          let Likes = item.Likes;
          let months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          let monthsAr = [
            "يناير",
            "فبراير",
            "مارس",
            "إبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
          ];
          let daysAr = ["الأحد", "الاثنين ", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
          var d = new Date(item.Published.toString());
          let date = d.getDate();
          let year = d.getFullYear();
          let day = days[d.getDay()];
          let month;

          var Title;
          var Description;
          if (flagEnglish) {
            Title = item.Title;
            Description = item.Description;
            month = months[d.getMonth()];
            day = days[d.getDay()];
            ItemURL = this.context.pageContext.site.absoluteUrl + "/en-us/Pages/newsdetail.aspx?newdid=" + item.ID;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/en-us/Pages/news.aspx";
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/en-us/Pages/newsdetail.aspx?newdid=" +
              item.ID;
          } else {
            Title = item.TitleAr;
            Description = item.DescriptionAr;
            month = monthsAr[d.getMonth()];
            day = daysAr[d.getDay()];
            ItemURL = this.context.pageContext.site.absoluteUrl + "/ar-ae/Pages/newsdetail.aspx?Parent=" + item.ID;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/ar-ae/Pages/news.aspx";
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/ar-ae/Pages/newsdetail.aspx?newsid=" +
              item.ID;
          }
          html += `<div class="card">
            <div class="card-body">
                <div class="row py-2 px-2">
                    <div class="col-sm-12 col-md-9">
                        <h3 class="fw-bold mb-0">${Title}</h3>
                    </div>
                    <div class="col-sm-12 col-md-3 my-auto text-end">
                        <a class="read-more w-100" href="${ListViewURL}">${feature_a}</a>
                        <p class="fw-bold w-100 mb-0">${date + ' ' + month + ' ' + year}</p>
                    </div>
                </div>
                <div class="row py-3 px-2">
                    <div class="col-sm-12">
                        <img src=${QLURL} class="img-fluid">
                        <p class="pt-4">${Description}</p>
                        <i class="bx bxs-quote-left"></i>
                        <h4 class="w-bold">${Title}</h4>
                        <p class="pt-4">${Description}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="d-flex flex-column comment-section">
                            <div class="bg-white p-2">
                                <p class="comments">Comments</p>
                               <div id="commentssection"></div>
                                <div class="mb-3 mt-5">
                                    <textarea class="form-control" rows="5" id="commentarea" name="text"></textarea>
                                  </div>
                                  <button class="btn btn-primary d-block ms-auto" id="btnsubmit">Submit</button>
                            </div>                         
                        </div>
                    </div>
                </div>
            </div>
        </div>`;
        });
      } else {
        html += ` <div class="card">
          <div class="card-body">
                    <div class="row">                 
                            <div class="news-text">${noDataFound}</div>
                        </div>
                    </div>
                </div>`;
      }
    } else {
      html += ` <div class="card">
        <div class="card-body">
                  <div class="row">                 
                          <div class="news-text">${noDataFound}</div>
                      </div>
                  </div>
              </div>`;
    }
    const listContainer: Element =
      this.domElement.querySelector("#spListContainer");
    listContainer.innerHTML = html;
    this._renderCommentsAsync();
    this._SubmitButtonclick();
  }

  private _renderCommentsList(res) {
    var SITEURL = this.context.pageContext.web.absoluteUrl;
    var flagEnglish = false;
    var noDataFound;
    var ListViewURL;
    var DetailViewUrl;
    var topic: string;
    var feature_a: string;
    var feature_b: string;

    if (SITEURL.indexOf("en") > -1) {
      flagEnglish = true;
      noDataFound = "No Data Found";
      topic = "Comments";

    } else {
      noDataFound = "لاتوجد بيانات";
      topic = "أخبار";
    }
    let html: string = "";
    var counter = 0;
    var totalcomments: Number = 0;
    var ItemURL;
    if (res != null) {
      if (res.value.length >= 1) {
        res.value.forEach((item) => {
          let months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
          let monthsAr = [
            "يناير",
            "فبراير",
            "مارس",
            "إبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
          ];
          let daysAr = ["الأحد", "الاثنين ", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
          var d = new Date(item.Created.toString());
          let date = d.getDate();
          let year = d.getFullYear();
          let day = days[d.getDay()];
          let Name=item.User_x0020_Name;
          let month;

          var Title;
          var Comments;
          if (flagEnglish) {
            Title = item.Title;
            Comments = item.User_x0020_Comments;
            month = months[d.getMonth()];
            day = days[d.getDay()];
          } else {
            Title = item.TitleAr;
            Comments = item.User_x0020_Comments_x0020_Ar;
            month = monthsAr[d.getMonth()];
            day = daysAr[d.getDay()];
          }
          html += `<div class="d-flex flex-row user-info">
          <img class="user-img" src="assets/images/icons/user.png">
          <div class="d-flex flex-column justify-content-start ms-2 my-auto">
              <span class="d-block font-weight-bold user-name">${Name}</span>
              <span class="date text-black">${date + ' ' + month + ' ' + year}</span>
          </div>
      </div>
      <div class="mt-3">
          <p class="comment-text">${Comments}</p>
      </div>`;
        });
      } else {
        html += `                 
         <div class="news-text">${noDataFound}</div>
         `;
      }
    } else {
      html += `<div class="news-text">${noDataFound}</div>`;
    }
    const listContainer: Element =
      this.domElement.querySelector("#commentssection");
    listContainer.innerHTML = html;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
