import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './DiscountshomewpWebPart.module.scss';
import * as strings from 'DiscountshomewpWebPartStrings';

import { SPComponentLoader } from '@microsoft/sp-loader';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface IDiscountshomewpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}

export interface SPListItem {
  ID: number;
  Title: string;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  ProgramDescription: string;
  ProgramDescriptionAr: string;
  StartDate: string;
  EndDate: string;
  DiscountDuration: string
}

export default class DiscountshomewpWebPart extends BaseClientSideWebPart<IDiscountshomewpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.discountshomewp}">
        <div id="spListContainer" >          
        </div>
    </div>`;

    SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/jquery/jquery.min.js', { globalExportsName: 'jQuery' }).then(($: any): void => {
      SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/bootstrap/js/bootstrap.bundle.min.js', { globalExportsName: 'bootstrap' }).then((): void => {
        this._renderList();
      });
    });
    //this._renderList();
  }

  private _getListData(): Promise<SPList> {
    var filterQuery =
      "?$filter=IsActive  eq '1'";
    var SiteURL =
      this.context.pageContext.site.absoluteUrl +
      `/_api/web/lists/GetByTitle('Discount Program')/Items` +
      filterQuery;
    return this.context.spHttpClient
      .get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }

  private _renderList() {
    this._getListData().then((response) => {
      var SITEURL = this.context.pageContext.web.absoluteUrl;
      var flagEnglish = false;
      var noDataFound;
      var offerviewurl;
      var DetailViewUrl;
      var topic: string;
      var feature_a: string;
      var feature_b: string;
      if (SITEURL.indexOf("en") > -1) {
        flagEnglish = true;
        noDataFound = "No Data Found";
        topic = "Offers";
        feature_a = "View All";
        feature_b = "Read More";
      } else {
        noDataFound = "لاتوجد بيانات";
        topic = "أخبار";
        feature_a = "مشاهدة الكل";
        feature_b = "اقرأ أكثر";
      }
      let html: string = "";
      html = `<div class="card discount-card">
      <div class="card-body">
          <div id="discount" class="carousel slide discount" data-bs-ride="carousel" data-bs-interval="false">
              <div class="carousel-inner">`;
      var counter = 0;
      console.log(response);
      if (response != null) {
        response.value.forEach((item: SPListItem) => {
          let QLURL = item["Image"].Url;
          let months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          let monthsAr = [
            "يناير",
            "فبراير",
            "مارس",
            "إبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
          ];

          var Title;
          var Description;
          if (flagEnglish) {
            Title = item.Title;
            Description = item.Description;
            offerviewurl =
              this.context.pageContext.web.absoluteUrl +
              "/en/Pages/DetailsListPage.aspx?Parent=" +
              item.ID;
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/en/Pages/DetailsPage.aspx?Parent=" +
              item.ID +
              "Discount Program";
          } else {
            Title = item.TitleAr;
            Description = item.DescriptionAr;
            offerviewurl =
              this.context.pageContext.web.absoluteUrl +
              "/ar/Pages/DetailsListPage.aspx?Parent=" +
              item.ID;
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/ar/Pages/DetailsPage.aspx?Parent=" +
              item.ID +
              "Discount Program";
          }

          if (counter == 0) {
            html += `
            <div class="carousel-item active">
                  <div class="d-flex justify-content-center gift-box">
                    <div class="text-center">
                     <img src=${QLURL} class="gift-icon">
                           <h3 class="mb-0 ff-secondary fw-bold text-center gift-text">${Description}</h3>
                          <a href="#" class="get-button">Get Now</a>
                    </div>
                  </div>
           </div>
            `;
            counter++;
          } else {
            html += `
            <div class="carousel-item">
                  <div class="d-flex justify-content-center gift-box">
                    <div class="text-center">
                     <img src=${QLURL} class="gift-icon">
                           <h3 class="mb-0 ff-secondary fw-bold text-center gift-text">${Description}</h3>
                          <a href="#" class="get-button">Get Now</a>
                    </div>
                  </div>
           </div>
            `;
          }
        });
      } else {
        html += `
        <div class="carousel-item active">
        <div class="d-flex justify-content-center gift-box">
          <div class="text-center">
           <img src="#" class="gift-icon">
                 <h3 class="mb-0 ff-secondary fw-bold text-center gift-text">${noDataFound}</h3>
                <a href="#" class="get-button">Get Now</a>
          </div>
        </div>
       </div>
        `;
      }
      html += `
      </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#discount" data-bs-slide="prev">
          <i class="bx bx-chevron-left"></i>
           </button>
            <button class="carousel-control-next" type="button" data-bs-target="#discount" data-bs-slide="next">
              <i class="bx bx-chevron-right"></i>
            </button>
             </div>
          </div>
        </div>
      `;
      const listContainer: Element =
        this.domElement.querySelector("#spListContainer");
      listContainer.innerHTML = html;
    });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
