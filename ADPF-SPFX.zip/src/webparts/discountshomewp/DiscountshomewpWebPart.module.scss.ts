/* tslint:disable */
require('./DiscountshomewpWebPart.module.css');
const styles = {
  discountshomewp: 'discountshomewp_3d6fe738',
  container: 'container_3d6fe738',
  row: 'row_3d6fe738',
  column: 'column_3d6fe738',
  'ms-Grid': 'ms-Grid_3d6fe738',
  title: 'title_3d6fe738',
  subTitle: 'subTitle_3d6fe738',
  description: 'description_3d6fe738',
  button: 'button_3d6fe738',
  label: 'label_3d6fe738',
};

export default styles;
/* tslint:enable */