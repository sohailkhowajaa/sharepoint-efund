import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

import styles from './EserviceswpWebPart.module.scss';
import * as strings from 'EserviceswpWebPartStrings';

export interface IEserviceswpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}

export interface SPListItem {
  ID: number;
  Title: string;
  TitleAr: string;
  link: string;
  parentid: number;
  icon: string;
  iconactive: string;
  target: string
}

let data;
let subboxes = [];
let html = ``;
let div;
let idiv;
let laststate = [];
let flagEnglish = false;

function _backbuttonclick(pid) {
  alert(pid);
  document.getElementById("preloader").style.display = "block";
  setTimeout(function () {
    document.getElementById("preloader").style.display = 'none';
  }, 500);
  if (pid == 0) {
    document.getElementById("subServicesRow").style.display = "none";
    document.getElementById("mainServicesRow").style.display = "block";
  } else {
    document.getElementById("subServicesRow").style.display = "block";
    if (laststate.length >= 1) {
      for (let index = 0; index < laststate.length; index++) {
        if (index == laststate.length - 1) {
          //document.getElementById("subServicesRow").innerHTML = laststate[index];
          //let div = document.createElement("div");
          document.getElementById("subServicesRow").style.display="none";
          //div.innerHTML="";
          //div.innerHTML=laststate[index];
          //div.appendChild(laststate[index]);
          //div.innerHTML = laststate[index];
          document.getElementById("subServicesRow").innerHTML = "";
          //document.querySelector(".eserviceswp_0afaad71").appendChild(div);
          document.getElementById("subServicesRow").appendChild(laststate[index]);

          laststate.splice(index);
        }
      }

    }
    document.getElementById("mainServicesRow").style.display = "none";
  }
}

function _submitevent(box) {
  let content;
  let id = box.getAttribute("boxid");
  let pid = _getparentid(id);
  let backdiv = document.createElement("div");
  backdiv.id = "backservices" + id;
  backdiv.classList.add("d-flex");
  backdiv.classList.add("align-items-center");
  backdiv.setAttribute("boxid", id);
  backdiv.addEventListener("click", function (e) {
   _backbuttonclick(pid);
  });
  let ineerhtml = `<i id="backToServices" boxid="${id}"  class="mdi mdi-chevron-left" style="font-size:40px;cursor:pointer"></i>
  <h3 class="mb-0 fw-bold" style="margin:0px;">${box.innerText}</h3>`;
  backdiv.innerHTML = ineerhtml;
  content = _getshtml(id);
  //let outer=document.createElement("div");
  //outer.innerHTML=content;
  if (content.innerHTML != "") {
    if (pid == 0 || pid == null) {
      laststate = [];
    } else {
      laststate.push(document.getElementById("subServicesRow").innerHTML);
    }
    document.getElementById("mainServicesRow").style.display = "none";
    document.getElementById("preloader").style.display = "block";
    setTimeout(function () {
      document.getElementById("preloader").style.display = 'none';
    }, 500);
    document.getElementById("backdiv").innerHTML = "";
    document.getElementById("backdiv").appendChild(backdiv);
    document.getElementById("subServicesRow").style.display = "block";
    document.getElementById("innerwrraper").innerHTML="";
    document.getElementById("innerwrraper").appendChild(content);
  }
}
function _getparentid(id) {
  let sameid = data.filter(function (e) {
    return id == e.ID;
  });
  return sameid[0].parentid;
}
function _getshtml(id) {
  //document.getElementById("innerwrraper").innerHTML = "";
  let main = document.createElement("div") as HTMLDivElement;
  let title = "";
  //alert(data[i - 1].ID);
  let html = ``;
  let sameid = data.filter(function (e) {
    return id == e.parentid;
  });
  if (sameid.length >= 1) {
    for (var i = 1; i <= sameid.length; i++) {
      if (!flagEnglish) {
        title = sameid[i - 1].TitleAr;
      } else {
        title = sameid[i - 1].Title;
      }
      let link = sameid[i - 1].link;
      let target = sameid[i - 1].target;
      let icon = sameid[i - 1].icon.Url;
      let icona = sameid[i - 1].iconactive.Url;
      if (link == "" || link == null) { link = "#"; target = ""; }
      let idiv = document.createElement("div") as HTMLElement;
      idiv.id = "services" + sameid[i - 1].ID;
      idiv.classList.add("col-md-3");
      idiv.classList.add("eservices-box");
      idiv.setAttribute("boxid", sameid[i - 1].ID);
      idiv.addEventListener("click", function (e) {
        //alert(this.getAttribute("boxid"));
       _submitevent(this);
      });
      html = `
        <a href="${link}" target="${target}" boxid="${sameid[i - 1].ID}">
            <div class="card cardHover">
                <div class="card-body">
                    <div class="icons-box">
                        <img src="${icon}" alt="icon" class="eservices-icons">
                        <img src="${icona}" alt="icon" class="eservices-icons img-top">
                    </div>
                    <p class="service-name">${title}</p>
                </div>
            </div>
        </a>`;
      idiv.innerHTML = html;
      main.appendChild(idiv);
    }
  }
  return main;
}
export default class EserviceswpWebPart extends BaseClientSideWebPart<IEserviceswpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="${styles.eserviceswp}">
      <div id="preloader" style="display: none;"></div>
        <div id="mainServicesRow" class="col-12">
            <h3 class="mb-0 fw-bold" id="topiceservice"></h3>
            <div class="row mt-4" style="flex-wrap: wrap;" id="eservicemain">
            </div>
        </div>
        <div id="subServicesRow" class="col-12" style="display: none;">
               
            <div id="backdiv">
            
            </div>
            <div class="row mt-4" style="flex-wrap: wrap;" id="innerwrraper">
            
            </div>

        </div>
    </div>`;
    this._renderListAsync();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListData(): Promise<SPList> {
    var filterQuery;
    filterQuery = "?$filter=IsActive  eq '1'&$orderby= Title desc";
    var SiteURL =
      this.context.pageContext.site.absoluteUrl +
      `/_api/web/lists/GetByTitle('eservices')/Items` +
      filterQuery;
    return this.context.spHttpClient
      .get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }

  private _renderListAsync(): void {
    this._getListData()
      .then((response) => {
        data = response.value;
        console.log(data);
        this._renderList();
      });
  }

  private _renderList() {
    var SITEURL = this.context.pageContext.web.absoluteUrl;
    var noDataFound;
    var topic: string;
    var feature_a: string;
    var feature_b: string;

    if (SITEURL.indexOf("en") > -1) {
      flagEnglish = true;
      noDataFound = "No Data Found";
      topic = "E-Services";
      feature_a = "View All";
      feature_b = "Read More";
    } else {
      noDataFound = "لاتوجد بيانات";
      topic = "E-Services Ar";
      feature_a = "مشاهدة الكل";
      feature_b = "اقرأ أكثر";
    }
    let html: string = "";
    html = ``;
    var counter = 0;
    var totalcomments: Number = 0;
    var ItemURL;
    document.getElementById("topiceservice").innerText = topic;
    if (data != null) {
      if (data.length >= 1) {
        for (var i = 1; i <= data.length; i++) {
          if (data[i - 1].parentid == 0) {
            div = document.createElement("div");
            div.id = "services" + data[i - 1].ID;
            div.classList.add("col-md-3");
            div.classList.add("eservices-box");
            div.setAttribute("boxid", data[i - 1].ID);
            let content = ``;
            content = this.getphtml(data[i - 1].ID);
            div.innerHTML = content;
            div.addEventListener("click", function (e) {

              //alert(this.getAttribute("boxid"));
             _submitevent(this);
            });
            let diveservice = document.getElementById("eservicemain");
            diveservice.appendChild(div);
          }
        }
      }
    }
  }

  public getphtml(id):string {
    let title = "";
    let html = ``;
    let sameid = data.filter(function (e) {
      return e.ID == id;
    });
    if (sameid.length >= 1) {
      for (var i = 1; i <= sameid.length; i++) {
        if (!flagEnglish) {
          title = sameid[i - 1].TitleAr;
        } else {
          title = sameid[i - 1].Title;
        }
        let icon = sameid[i - 1].icon.Url;
        let icona = sameid[i - 1].iconactive.Url;
        let link = sameid[i - 1].link;
        let target = sameid[i - 1].target;
        if (link == "" || link == null) { link = "#"; target = ""; }
        html += `
            <a href="${link}" target="${target}">
                <div class="card cardHover">
                    <div class="card-body">
                        <div class="icons-box">
                            <img src="${icon}" alt="icon" class="eservices-icons">
                            <img src="${icona}" alt="icon" class="eservices-icons img-top">
                        </div>
                        <p class="service-name">${title}</p>
                    </div>
                </div>
            </a>`;
      }
    }
    return html;
  }

  public submitevent(box):void {
    let content;
    let id = box.getAttribute("boxid");
    let pid = this.getparentid(id);
    let backdiv = document.createElement("div");
    backdiv.id = "backservices" + id;
    backdiv.classList.add("d-flex");
    backdiv.classList.add("align-items-center");
    backdiv.setAttribute("boxid", id);
    let ineerhtml = `<i id="backToServices" onclick="backbuttonclick(${pid})" boxid="${id}"  class="mdi mdi-chevron-left" style="font-size:40px;cursor:pointer"></i>
    <h3 class="mb-0 fw-bold">${box.innerText}</h3>`;
    backdiv.innerHTML = ineerhtml;
    content = this.getshtml(id);
    if (content != "") {
      if (pid == 0 || pid == null) {
        laststate = [];
      } else {
        laststate.push(document.getElementById("subServicesRow").innerHTML);
      }
      document.getElementById("mainServicesRow").style.display = "none";
      document.getElementById("preloader").style.display = "block";
      setTimeout(function () {
        document.getElementById("preloader").style.display = 'none';
      }, 500);
      document.getElementById("backdiv").innerHTML = "";
      document.getElementById("backdiv").appendChild(backdiv);
      document.getElementById("subServicesRow").style.display = "block";
      document.getElementById("innerwrraper").innerHTML = content;
    }
  }

  public getshtml(id):string {
    //document.getElementById("innerwrraper").innerHTML = "";
    let main = document.createElement("div") as HTMLDivElement;
    let title = "";
    //alert(data[i - 1].ID);
    let html = ``;
    let sameid = data.filter(function (e) {
      return id == e.parentid;
    });
    if (sameid.length >= 1) {
      for (var i = 1; i <= sameid.length; i++) {
        if (!flagEnglish) {
          title = sameid[i - 1].TitleAr;
        } else {
          title = sameid[i - 1].Title;
        }
        let link = sameid[i - 1].link;
        let target = sameid[i - 1].target;
        let icon = sameid[i - 1].icon.Url;
        let icona = sameid[i - 1].iconactive.Url;
        if (link == "" || link == null) { link = "#"; target = ""; }
        let idiv = document.createElement("div") as HTMLElement;
        idiv.id = "services" + sameid[i - 1].ID;
        idiv.classList.add("col-md-3");
        idiv.classList.add("eservices-box");
        idiv.setAttribute("boxid", sameid[i - 1].ID);
        html = `
          <a href="${link}" target="${target}" onclick="submitevent(this);" boxid="${sameid[i - 1].ID}">
              <div class="card cardHover">
                  <div class="card-body">
                      <div class="icons-box">
                          <img src="${icon}" alt="icon" class="eservices-icons">
                          <img src="${icona}" alt="icon" class="eservices-icons img-top">
                      </div>
                      <p class="service-name">${title}</p>
                  </div>
              </div>
          </a>`;
        idiv.innerHTML = html;
        main.appendChild(idiv);
      }
    }
    return main.innerHTML;
  }

  public backbuttonclick(pid): void {
    document.getElementById("preloader").style.display = "block";
    setTimeout(function () {
      document.getElementById("preloader").style.display = 'none';
    }, 500);
    if (pid == 0) {
      document.getElementById("subServicesRow").style.display = "none";
      document.getElementById("mainServicesRow").style.display = "block";
    } else {
      document.getElementById("subServicesRow").style.display = "block";
      if (laststate.length >= 1) {
        for (let index = 0; index < laststate.length; index++) {
          if (index == laststate.length - 1) {
            document.getElementById("subServicesRow").innerHTML = laststate[index];
            laststate.splice(index);
          }
        }

      }
      document.getElementById("mainServicesRow").style.display = "none";
    }
  }

  public getparentid(id):number {
    let sameid = data.filter(function (e) {
      return id == e.ID;
    });
    return sameid[0].parentid;
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
