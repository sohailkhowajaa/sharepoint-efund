/* tslint:disable */
require('./EserviceswpWebPart.module.css');
const styles = {
  eserviceswp: 'eserviceswp_0afaad71',
  container: 'container_0afaad71',
  row: 'row_0afaad71',
  column: 'column_0afaad71',
  'ms-Grid': 'ms-Grid_0afaad71',
  title: 'title_0afaad71',
  subTitle: 'subTitle_0afaad71',
  description: 'description_0afaad71',
  button: 'button_0afaad71',
  label: 'label_0afaad71',
  preloader: 'preloader_0afaad71',
  'animate-preloader': 'animate-preloader_0afaad71',
};

export default styles;
/* tslint:enable */