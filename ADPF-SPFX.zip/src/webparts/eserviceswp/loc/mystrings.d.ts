declare interface IEserviceswpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EserviceswpWebPartStrings' {
  const strings: IEserviceswpWebPartStrings;
  export = strings;
}
