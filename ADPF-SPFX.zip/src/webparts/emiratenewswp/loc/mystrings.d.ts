declare interface IEmiratenewswpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EmiratenewswpWebPartStrings' {
  const strings: IEmiratenewswpWebPartStrings;
  export = strings;
}
