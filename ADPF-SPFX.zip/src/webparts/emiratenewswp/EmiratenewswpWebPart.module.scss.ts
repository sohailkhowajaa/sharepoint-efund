/* tslint:disable */
require('./EmiratenewswpWebPart.module.css');
const styles = {
  emiratenewswp: 'emiratenewswp_16ea2ada',
  container: 'container_16ea2ada',
  row: 'row_16ea2ada',
  column: 'column_16ea2ada',
  'ms-Grid': 'ms-Grid_16ea2ada',
  title: 'title_16ea2ada',
  subTitle: 'subTitle_16ea2ada',
  description: 'description_16ea2ada',
  button: 'button_16ea2ada',
  label: 'label_16ea2ada',
};

export default styles;
/* tslint:enable */