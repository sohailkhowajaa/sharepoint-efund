import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './EmiratenewswpWebPart.module.scss';
import * as strings from 'EmiratenewswpWebPartStrings';

import {
  HttpClient,
  HttpClientResponse,
  IHttpClientOptions
} from '@microsoft/sp-http';


export interface IEmiratenewswpWebPartProps {
  description: string;
}

export interface emiratenews {
  value: newsitem[];
}

export interface newsitem {
  Description: string;
  DescriptionAr: string;

}
export default class EmiratenewswpWebPart extends BaseClientSideWebPart<IEmiratenewswpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.emiratenewswp}">
        <div id="spListContainer" >          
        </div>
    </div>`;
    this._renderList();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListData(): Promise<emiratenews> {
    var apiurl = `http://wam.ae/en/rss/emirates`;
    const httpClientOptions: IHttpClientOptions = {
      headers: new Headers(),
      method: "GET",
      mode: "cors"
  };
    return this.context.httpClient
      .get(apiurl, HttpClient.configurations.v1, httpClientOptions)
      .then((response) => {
        return response.json();
      });
  }

  private _getdata():Promise<any>{
    var apiurl = `http://wam.ae/en/rss/emirates`;
    var apiurla = `http://localhost:4050/news/`;
    return this.context.httpClient
    .get(apiurla, HttpClient.configurations.v1,
      {
        headers: [
          ['accept', 'application/xml'],
        ]
      })
    .then((res: HttpClientResponse): Promise<any> => {
      return res.json();
    })

    
  }

  private _renderList() {
    this._getdata().then((response) => {
      console.log(response);
      var SITEURL = this.context.pageContext.web.absoluteUrl;
      var flagEnglish = false;
      var noDataFound;
      var ListViewURL;
      var DetailViewUrl;
      var topic: string;
      var feature_a: string;
      var feature_b: string;
      if (SITEURL.indexOf("en") > -1) {
        flagEnglish = true;
        noDataFound = "No Data Found";
        topic = "News";
        feature_a = "View All";
        feature_b = "Read More";
      } else {
        noDataFound = "لاتوجد بيانات";
        topic = "أخبار";
        feature_a = "مشاهدة الكل";
        feature_b = "اقرأ أكثر";
      }
      let html: string = `<div class="card emirate-news-card">
      <div class="card-header">
          <div class="row">
              <div class="col-sm-12 col-md-10 col-lg-11">
                  <h3 class="emirate-news mb-0">Emirate News</h3>
              </div>
              <div class="col-sm-12 col-md-2 col-lg-1 emirate-news-nav">
                  <button class="carousel-control-prev" type="button" data-bs-target="#emiratenews" data-bs-slide="prev">
                      <i class="bx bx-chevron-left"></i>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#emiratenews" data-bs-slide="next">
                      <i class="bx bx-chevron-right"></i>
                  </button>
              </div>
              
          </div>
      </div>
      <div class="card-body">
          <div class="row px-2 py-1">
              <div id="emiratenews" class="carousel slide vertical" data-bs-ride="carousel" data-bs-interval="3000">
                  <div class="carousel-inner">`;
      var counter = 0;
      console.log(response);
      if (response != null) {
        response.forEach((item: newsitem) => {
          let months = [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
          ];
          let monthsAr = [
            "يناير",
            "فبراير",
            "مارس",
            "إبريل",
            "مايو",
            "يونيو",
            "يوليو",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
          ];

          var Title;
          var Description;
          if (flagEnglish) {
            Description = item.Description;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/en/Pages/DetailsListPage.aspx?Parent=";
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/en/Pages/DetailsPage.aspx?Parent=";
          } else {
            Description = item.DescriptionAr;
            ListViewURL =
              this.context.pageContext.web.absoluteUrl +
              "/ar/Pages/DetailsListPage.aspx?Parent=";
            DetailViewUrl =
              this.context.pageContext.site.absoluteUrl +
              "/ar/Pages/DetailsPage.aspx?Parent=";
          }

          if (counter == 0) {
            html += `
            <div class="carousel-item vertical active">
             <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            </div>
            `;
            counter++;
          } else {
            html += `
            <div class="carousel-item vertical">
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            </div>
            `;
          }
        });
      } else {
        html += `
        <div class="carousel-item vertical active">
          <p>${noDataFound}</p>
        </div>
        `;
      }

      html += `
      </div>
      </div>
      </div>
      </div>
     </div>
      `;
      const listContainer: Element =
        this.domElement.querySelector("#spListContainer");
      listContainer.innerHTML = html;
    });
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
