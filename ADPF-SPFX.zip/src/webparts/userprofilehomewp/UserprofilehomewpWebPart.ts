import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './UserprofilehomewpWebPart.module.scss';
import * as strings from 'UserprofilehomewpWebPartStrings';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';
export interface IUserprofilehomewpWebPartProps {
  description: string;
}

export default class UserprofilehomewpWebPart extends BaseClientSideWebPart<IUserprofilehomewpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
      <div class="${styles.userprofilehomewp}">
      <div id="userprofiledata">          
      </div>
      </div>`;
      this._renderData();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }
  
  private async getCurrentUserWithAsyncAwait() {
    let userlogin = "'ADPENTEST\\efunddb'";
    userlogin=this.context.pageContext.user.loginName;
    console.log(userlogin);
    var url_a=this.context.pageContext.site.absoluteUrl + `/_api/SP.UserProfiles.PeopleManager/GetMyProperties?$select=PictureUrl,AccountName,Title,DisplayName,PersonalUrl`;
    var url = this.context.pageContext.site.absoluteUrl + `/_api/SP.UserProfiles.PeopleManager/GetPropertiesFor(accountName=@v)?@v=`+userlogin;
    var response = await this.context.spHttpClient.get(url_a, SPHttpClient.configurations.v1);
    return await response.json();
  }

  private _renderData() {
    this.getCurrentUserWithAsyncAwait().then((res) => {
      console.log(res);
      var designation = res.Title;
      var picurl = res.PictureUrl;
      var profileurl=res.PersonalUrl;
      if(picurl==null||picurl==undefined)
      {
      picurl="https://amratalpha.github.io/adpfdesign/assets/images/users/avatar-2.jpg";
      }
      var displaname=res.DisplayName;
      if (res != null) {
        var html: string = `<div class="card profile-card">
      <div class="card-body d-block mx-auto py-4">
          <img src=${picurl} class="user">
          <h3 class="name">${displaname}</h3>
          <h4 class="designation">${designation}</h4>
          <a href=${profileurl} class="profile text-center">View Profile</a>
      </div>
    </div>`;
      } else {
        html = `<div class="card profile-card">
    <div class="card-body d-block mx-auto py-4">
        <img src="https://amratalpha.github.io/adpfdesign/assets/images/users/avatar-2.jpg" class="user">
        <h3 class="name"></h3>
        <h4 class="designation"></h4>
        <a href="#" class="profile text-center"></a>
    </div>
  </div>`;
      }
      const listContainer: Element = this.domElement.querySelector("#userprofiledata");
      listContainer.innerHTML = html;
    })
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
