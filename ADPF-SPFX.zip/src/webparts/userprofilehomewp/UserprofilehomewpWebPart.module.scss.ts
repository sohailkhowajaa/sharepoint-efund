/* tslint:disable */
require('./UserprofilehomewpWebPart.module.css');
const styles = {
  userprofilehomewp: 'userprofilehomewp_6308bbf1',
  container: 'container_6308bbf1',
  row: 'row_6308bbf1',
  column: 'column_6308bbf1',
  'ms-Grid': 'ms-Grid_6308bbf1',
  title: 'title_6308bbf1',
  subTitle: 'subTitle_6308bbf1',
  description: 'description_6308bbf1',
  button: 'button_6308bbf1',
  label: 'label_6308bbf1',
};

export default styles;
/* tslint:enable */