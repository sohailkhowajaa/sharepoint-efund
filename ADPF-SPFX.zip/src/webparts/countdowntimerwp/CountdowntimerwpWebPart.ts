import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './CountdowntimerwpWebPart.module.scss';
import * as strings from 'CountdowntimerwpWebPartStrings';

import { SPComponentLoader } from '@microsoft/sp-loader';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface ICountdowntimerwpWebPartProps {
  description: string;
}

export interface CountdownList {
  value: CountdownListItem[];
}
export interface CountdownListItem {
  Title: string;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  PublishedDate: Date;
  ExpiryDate: Date;
  IsActive: boolean;
  Start: Date;
  End: Date;

}

export default class CountdowntimerwpWebPart extends BaseClientSideWebPart<ICountdowntimerwpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.countdowntimerwp}">
    <div id="spListContainer" >          
      </div>
      <div id="timemain" >          
      </div>
    </div>`;

    SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/jquery/jquery.min.js', { globalExportsName: 'jQuery' }).then(($: any): void => {
      SPComponentLoader.loadScript(this.context.pageContext.site.absoluteUrl + '/_catalogs/masterpage/assets/libs/bootstrap/js/bootstrap.bundle.min.js', { globalExportsName: 'bootstrap' }).then((): void => {
        this._renderList();
      });
    });
    //this._renderList();
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  private _getListData(): Promise<CountdownList> {
    var filterQuery = "?$top=2&$filter=IsActive  eq '1'&$orderby= PublishedDate desc ";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('Countdown Timer')/Items` + filterQuery;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }
  private _renderList(): void {
    this._getListData()
      .then((response) => {
        var SITEURL = this.context.pageContext.web.absoluteUrl;
        var flagEnglish = false;
        var noDataFound;

        if (SITEURL.indexOf('en') > -1) {
          flagEnglish = true;
          noDataFound = "No Data Found";
        } else {
          noDataFound = "لاتوجد بيانات";
        }

        let html: string = `<div class="card coming-soon-card">
        <div class="card-body">
            <div id="coming" class="carousel slide" data-bs-ride="carousel" data-bs-interval="false">
                <div class="carousel-inner">`;
        var counter = 0;
        if (response != null) {
          response.value.forEach((item: CountdownListItem) => {
            var Title;
            var Description;
            let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            let monthsAr = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
            var p = new Date(item.PublishedDate.toString());
            var e = new Date(item.ExpiryDate.toString());
            var sd = new Date(item.Start.toString());
            var ed = new Date(item.End.toString());
            let publishedDate = p.getDate();
            let publishedYear = p.getFullYear();
            let expiryDate = e.getDate();
            let expiryYear = e.getFullYear();
            let publishedMonth;
            let expiryMonth;
            const t = this.getTimeRemaining(ed);
            var days=t.days;
            var hours=t.hours;
            var mins=t.minutes;
            var seconds=t.seconds;
            var dys = "Days";
            if (days <= 1) {
              dys = "Day";
            }

            if (flagEnglish) {
              Title = item.Title;
              Description = item.Description;
              publishedMonth = months[p.getMonth()];
              expiryMonth = months[e.getMonth()];

            } else {
              Title = item.TitleAr;
              Description = item.DescriptionAr;
              publishedMonth = monthsAr[p.getMonth()];
              expiryMonth = monthsAr[e.getMonth()];

            }

            if (counter == 0) {
              html += `<div class="carousel-item active">
              <div class="text-center">
                  <h3 class="coming">${Title}</h3>
                  <p class="day">${days}</p>
                  <p class="days">${dys}</p>
                  <p class="time">${hours}:${mins}:${seconds}</p>
              </div>
          </div>`;
              counter++;
            } else {
              html += `<div class="carousel-item">
              <div class="text-center">
                  <h3 class="coming">${Title}</h3>
                  <p class="day">${days}</p>
                  <p class="days">${dys}</p>
                  <p class="time">${hours}:${mins}:${seconds}}</p>
              </div>
          </div>`;
            }
          });
        }
        else {
          html += `<div class="carousel-item">
              <div class="text-center">
                  <h3 class="coming">${noDataFound}</h3>
                  <p class="day"></p>
                  <p class="days"></p>
                  <p class="time"></p>
              </div>
          </div>`;
        }
        html += `</div>                                                    
        <button class="carousel-control-prev" type="button" data-bs-target="#coming" data-bs-slide="prev">
            <i class="bx bx-chevron-left"></i>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#coming" data-bs-slide="next">
            <i class="bx bx-chevron-right"></i>
        </button>
    </div>
</div>
</div>`;
        const listContainer: Element = this.domElement.querySelector('#spListContainer');
        listContainer.innerHTML = html;
      });
  }
  private getTimeRemaining(endtime){
    var countDownDate = endtime.getTime();
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    return {
      distance,
      days,
      hours,
      minutes,
      seconds
    };
  }
  private timerset(): void {
    var countDownDate = new Date("Aug 10 2022 17:21:32").getTime();
    var x = setInterval(function () {
      var now = new Date().getTime();
      var distance = countDownDate - now;
      var days = Math.floor(distance / (1000 * 60 * 60 * 24));
      var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      var seconds = Math.floor((distance % (1000 * 60)) / 1000);
      document.getElementById("timemain").innerHTML = days + "d " + hours + "h "
        + minutes + "m " + seconds + "s ";
      if (distance < 0) {
        clearInterval(x);
        alert('Time Up!!');
      }
    }, 1000);

  }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
