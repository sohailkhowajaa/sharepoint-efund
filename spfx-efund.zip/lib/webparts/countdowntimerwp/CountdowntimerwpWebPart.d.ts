import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface ICountdowntimerwpWebPartProps {
    description: string;
}
export interface CountdownList {
    value: CountdownListItem[];
}
export interface CountdownListItem {
    Title: string;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    PublishedDate: Date;
    ExpiryDate: Date;
    IsActive: boolean;
    Start: Date;
    End: Date;
}
export default class CountdowntimerwpWebPart extends BaseClientSideWebPart<ICountdowntimerwpWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    private _getListData();
    private _renderList();
    private getTimeRemaining(endtime);
    private timerset();
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
