import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IGalleryhomewpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    Title: string;
}
export default class GalleryhomewpWebPart extends BaseClientSideWebPart<IGalleryhomewpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderList();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
