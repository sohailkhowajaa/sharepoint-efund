import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface IFavoritehomewpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    Title: string;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    Url: string;
}
export default class FavoritehomewpWebPart extends BaseClientSideWebPart<IFavoritehomewpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderList();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
