import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
export interface INewsHomewpWebPartProps {
    description: string;
}
export interface SPList {
    value: SPListItem[];
}
export interface SPListItem {
    ID: number;
    Title: string;
    TitleAr: string;
    Description: string;
    DescriptionAr: string;
    Published: Date;
    ImageUrl: string;
}
export default class NewsHomewpWebPart extends BaseClientSideWebPart<INewsHomewpWebPartProps> {
    render(): void;
    private _getListData();
    private _renderList();
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
