/* tslint:disable */
require('./GalleryhomewpWebPart.module.css');
const styles = {
  galleryhomewp: 'galleryhomewp_da25eff9',
  container: 'container_da25eff9',
  row: 'row_da25eff9',
  column: 'column_da25eff9',
  'ms-Grid': 'ms-Grid_da25eff9',
  title: 'title_da25eff9',
  subTitle: 'subTitle_da25eff9',
  description: 'description_da25eff9',
  button: 'button_da25eff9',
  label: 'label_da25eff9',
};

export default styles;
/* tslint:enable */