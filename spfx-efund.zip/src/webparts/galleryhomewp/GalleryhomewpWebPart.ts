import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './GalleryhomewpWebPart.module.scss';
import * as strings from 'GalleryhomewpWebPartStrings';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface IGalleryhomewpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}
export interface SPListItem {
  Title: string;
}

export default class GalleryhomewpWebPart extends BaseClientSideWebPart<IGalleryhomewpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.galleryhomewp}">
        <div id="spListContainer" >          
        </div>
    </div>`;
    this._renderList();
  }

  private _getListData(): Promise<SPList> {
    // var filterQuery = "?$filter=IsActive  eq '1'";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('Gallery')/Items`;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }
  private _renderList(): void {
    this._getListData()
      .then((response) => {
        var SITEURL = this.context.pageContext.web.absoluteUrl;
        var flagEnglish = false;
        var noDataFound;
        if (SITEURL.indexOf('en') > -1) {
          flagEnglish = true;
          noDataFound = "No Data Found";
        } else {
          noDataFound = "لاتوجد بيانات";
        }
        let html: string = `<div class="card gallery-card">
        <div class="card-header">
            <div class="row">
                <div class="col-sm-12 col-md-10">
                    <h3 class="gallery mb-0">Gallery</h3>
                </div>
                <div class="col-sm-12 col-md-2 gallery-nav">
                    <button class="carousel-control-prev" type="button" data-bs-target="#gallery" data-bs-slide="prev">
                        <i class="bx bx-chevron-left"></i>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#gallery" data-bs-slide="next">
                        <i class="bx bx-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div id="gallery" class="carousel slide" data-ride="carousel" data-bs-interval="false">
                    <div class="carousel-inner">`;
        var counter = 0;
        var pagecount = 7;
        var pagesize;
        if (response != null) {
          // var count = response.value.length;
          console.log(response);
          response.value.forEach((item: SPListItem) => {
            var Title;
            var Description;
            let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            let monthsAr = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
            if (counter == 0) {
              html += `<div class="carousel-item active">
            <div class="portfolio-item row">
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="assets/images/news/building.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="assets/images/news/building.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
                <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                    <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                        <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                    </a>
                </div>
            </div>
        </div>`;
              counter++;
            } else {
              html += `<div class="carousel-item">
              <div class="portfolio-item row">
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="assets/images/news/building.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="assets/images/news/building.jpg" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
                  <div class="item col-sm col-6 col-md-3 col-lg-3 col-xl-3">
                      <a href="#" class="fancylight popup-btn" data-fancybox-group="light">
                          <img class="img-fluid" src="http://pft-efundapp/sites/efund/Gallery/building1.jpg" alt="">
                      </a>
                  </div>
              </div>
          </div>`;
            }
          });
        }
        else {
          html += `<div class="col-4 text-center">
         ${noDataFound}
      </div>`;
        }
        html += `</div>
        </div>
    </div>
</div>
</div>`;
        const listContainer: Element = this.domElement.querySelector('#spListContainer');
        listContainer.innerHTML = html;
      });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
