declare interface IGalleryhomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GalleryhomewpWebPartStrings' {
  const strings: IGalleryhomewpWebPartStrings;
  export = strings;
}
