/* tslint:disable */
require('./EventshomewpWebPart.module.css');
const styles = {
  eventshomewp: 'eventshomewp_3a60773f',
  container: 'container_3a60773f',
  row: 'row_3a60773f',
  column: 'column_3a60773f',
  'ms-Grid': 'ms-Grid_3a60773f',
  title: 'title_3a60773f',
  subTitle: 'subTitle_3a60773f',
  description: 'description_3a60773f',
  button: 'button_3a60773f',
  label: 'label_3a60773f',
};

export default styles;
/* tslint:enable */