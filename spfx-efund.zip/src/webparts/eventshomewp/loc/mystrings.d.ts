declare interface IEventshomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'EventshomewpWebPartStrings' {
  const strings: IEventshomewpWebPartStrings;
  export = strings;
}
