declare interface IDiscountshomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'DiscountshomewpWebPartStrings' {
  const strings: IDiscountshomewpWebPartStrings;
  export = strings;
}
