/* tslint:disable */
require('./NewsHomewpWebPart.module.css');
const styles = {
  newsHomewp: 'newsHomewp_dc5955b7',
  container: 'container_dc5955b7',
  row: 'row_dc5955b7',
  column: 'column_dc5955b7',
  'ms-Grid': 'ms-Grid_dc5955b7',
  title: 'title_dc5955b7',
  subTitle: 'subTitle_dc5955b7',
  description: 'description_dc5955b7',
  button: 'button_dc5955b7',
  label: 'label_dc5955b7',
  list: 'list_dc5955b7',
  listItem: 'listItem_dc5955b7',
};

export default styles;
/* tslint:enable */