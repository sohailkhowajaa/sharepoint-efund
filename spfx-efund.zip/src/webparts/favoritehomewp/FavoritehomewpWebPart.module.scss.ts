/* tslint:disable */
require('./FavoritehomewpWebPart.module.css');
const styles = {
  favoritehomewp: 'favoritehomewp_42a745d5',
  container: 'container_42a745d5',
  row: 'row_42a745d5',
  column: 'column_42a745d5',
  'ms-Grid': 'ms-Grid_42a745d5',
  title: 'title_42a745d5',
  subTitle: 'subTitle_42a745d5',
  description: 'description_42a745d5',
  button: 'button_42a745d5',
  label: 'label_42a745d5',
};

export default styles;
/* tslint:enable */