import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import styles from './FavoritehomewpWebPart.module.scss';
import * as strings from 'FavoritehomewpWebPartStrings';

import {
  SPHttpClient,
  SPHttpClientResponse
} from '@microsoft/sp-http';

export interface IFavoritehomewpWebPartProps {
  description: string;
}

export interface SPList {
  value: SPListItem[];
}
export interface SPListItem {
  Title: string;
  TitleAr: string;
  Description: string;
  DescriptionAr: string;
  Url: string
}

export default class FavoritehomewpWebPart extends BaseClientSideWebPart<IFavoritehomewpWebPartProps> {

  public render(): void {
    this.domElement.innerHTML = `
    <div class="${styles.favoritehomewp}">
        <div id="spListContainer" >          
        </div>
    </div>`;
    this._renderList();
  }

  private _getListData(): Promise<SPList> {
    var filterQuery = "?$filter=IsActive  eq '1'";
    var SiteURL = this.context.pageContext.site.absoluteUrl + `/_api/web/lists/GetByTitle('Favorite Shortcuts')/Items` + filterQuery;
    return this.context.spHttpClient.get(SiteURL, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        return response.json();
      });
  }
  private _renderList(): void {
    this._getListData()
      .then((response) => {
        var SITEURL = this.context.pageContext.web.absoluteUrl;
        var flagEnglish = false;
        var noDataFound;
        if (SITEURL.indexOf('en') > -1) {
          flagEnglish = true;
          noDataFound = "No Data Found";
        } else {
          noDataFound = "لاتوجد بيانات";
        }
        let html: string = `<div class="card shortcuts-card">
        <div class="card-header">
            <div class="row">
                <div class="col-sm-12 col-md-10">
                    <h3 class="shortcuts mb-0">Favorite Shortcuts</h3>
                </div>
                <div class="col-sm-12 col-md-2 shortcuts-nav">
                    <button class="carousel-control-prev" type="button" data-bs-target="#quicklinks" data-bs-slide="prev">
                        <i class="bx bx-chevron-left"></i>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#quicklinks" data-bs-slide="next">
                        <i class="bx bx-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div id="quicklinks" class="carousel slide" data-ride="carousel" data-bs-interval="false">
                <div class="carousel-inner px-2">`;
        var counter = 0;
        var pagecount = 7;
        var pagesize;
        if (response != null) {
          var count = response.value.length;
          if (count >= 1) {
            pagesize = Math.ceil(count / pagecount);
            response.value.forEach((item: SPListItem) => {
              let QLURL = item["Image"].Url;
              var Title;
              var Description;
              let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
              let monthsAr = ["يناير", "فبراير", "مارس", "إبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

              if (flagEnglish) {
                Title = item.Title;
                Description = item.Description;
              } else {
                Title = item.TitleAr;
                Description = item.DescriptionAr;
              }
              if (counter == 0) {
                html += `<div class="carousel-item active">
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">HR Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">HR Loans</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">CCD Services</p>
                      </div>
                  </div>
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">GS Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">Legal Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">BED Services</p>
                      </div>
                  </div>
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center"></div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">Finance Services</p>
                      </div>
                      <div class="col-4 text-center"></div>
                  </div>
              </div>`;
              counter++;
              } else {
                html += `<div class="carousel-item">
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">HR Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">HR Loans</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">CCD Services</p>
                      </div>
                  </div>
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">GS Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">Legal Services</p>
                      </div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">BED Services</p>
                      </div>
                  </div>
                  <div class="row quicklinks-row">
                      <div class="col-4 text-center"></div>
                      <div class="col-4 text-center">
                          <img src="https://amratalpha.github.io/adpfdesign/assets/images/icons/school-material.png" class="quicklinks-icons">
                          <p class="pt-2">Finance Services</p>
                      </div>
                      <div class="col-4 text-center"></div>
                  </div>
              </div>`;
              }
            });
          }
        }
        else {
          html += `<div class="col-4 text-center">
         ${noDataFound}
      </div>`;
        }
        html += `</div>
        </div>
    </div>
</div>`;
        const listContainer: Element = this.domElement.querySelector('#spListContainer');
        listContainer.innerHTML = html;
      });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
