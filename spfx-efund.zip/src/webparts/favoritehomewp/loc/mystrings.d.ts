declare interface IFavoritehomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FavoritehomewpWebPartStrings' {
  const strings: IFavoritehomewpWebPartStrings;
  export = strings;
}
