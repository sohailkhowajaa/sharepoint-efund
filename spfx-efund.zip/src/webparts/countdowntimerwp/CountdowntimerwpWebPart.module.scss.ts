/* tslint:disable */
require('./CountdowntimerwpWebPart.module.css');
const styles = {
  countdowntimerwp: 'countdowntimerwp_8eddbacd',
  container: 'container_8eddbacd',
  row: 'row_8eddbacd',
  column: 'column_8eddbacd',
  'ms-Grid': 'ms-Grid_8eddbacd',
  title: 'title_8eddbacd',
  subTitle: 'subTitle_8eddbacd',
  description: 'description_8eddbacd',
  button: 'button_8eddbacd',
  label: 'label_8eddbacd',
};

export default styles;
/* tslint:enable */