declare interface ICountdowntimerwpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CountdowntimerwpWebPartStrings' {
  const strings: ICountdowntimerwpWebPartStrings;
  export = strings;
}
