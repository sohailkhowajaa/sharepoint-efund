declare interface IUserprofilehomewpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserprofilehomewpWebPartStrings' {
  const strings: IUserprofilehomewpWebPartStrings;
  export = strings;
}
